using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms.VisualStyles;
using System.Xml;

namespace DataTierGenerator
{
    /// <summary>
    /// Generates C# data access and data transfer classes.
    /// </summary>
    internal static class CsGenerator
    {
        /// <summary>
        /// Creates a project file that references each generated C# code file for data access.
        /// </summary>
        /// <param name="path">The path where the project file should be created.</param>
        /// <param name="projectName">The name of the project.</param>
        /// <param name="tableList">The list of tables code files were created for.</param>
        /// <param name="daoPrefix">The suffix to append to the name of each data access class.</param>
        /// <param name="dtoSuffix">The suffix to append to the name of each data transfer class.</param>
        public static void CreateProjectFile(string path, string projectName, List<Table> tableList, string daoPrefix, string dtoSuffix)
        {
            string projectXml = Utility.GetResource("DataTierGenerator.Resources.Project.xml");
            XmlDocument document = new XmlDocument();
            document.LoadXml(projectXml);

            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(document.NameTable);
            namespaceManager.AddNamespace(String.Empty, "http://schemas.microsoft.com/developer/msbuild/2003");
            namespaceManager.AddNamespace("msbuild", "http://schemas.microsoft.com/developer/msbuild/2003");

            document.SelectSingleNode("/msbuild:Project/msbuild:PropertyGroup/msbuild:ProjectGuid", namespaceManager).InnerText = "{" + Guid.NewGuid().ToString() + "}";
            document.SelectSingleNode("/msbuild:Project/msbuild:PropertyGroup/msbuild:RootNamespace", namespaceManager).InnerText = projectName;
            document.SelectSingleNode("/msbuild:Project/msbuild:PropertyGroup/msbuild:AssemblyName", namespaceManager).InnerText = projectName;

            XmlNode itemGroupNode = document.SelectSingleNode("/msbuild:Project/msbuild:ItemGroup[msbuild:Compile]", namespaceManager);
            foreach (Table table in tableList)
            {
                string className = Utility.FormatClassName(table.Name);
                var aTable = table.Name.Split('_');
                if (aTable.Length > 1)
                {
                    className = table.Name.Replace(aTable[0] + "_", "");
                }

                XmlNode dtoCompileNode = document.CreateElement("Compile", "http://schemas.microsoft.com/developer/msbuild/2003");
                XmlAttribute dtoAttribute = document.CreateAttribute("Include");
                dtoAttribute.Value = Path.Combine(table.Name, className + dtoSuffix + ".cs");
                dtoCompileNode.Attributes.Append(dtoAttribute);
                itemGroupNode.AppendChild(dtoCompileNode);


                XmlNode interfaceCompileNode = document.CreateElement("Compile", "http://schemas.microsoft.com/developer/msbuild/2003");
                XmlAttribute interfaceAttribute = document.CreateAttribute("Include");
                interfaceAttribute.Value = Path.Combine(table.Name, "I" + className + ".cs");
                interfaceCompileNode.Attributes.Append(interfaceAttribute);
                itemGroupNode.AppendChild(interfaceCompileNode);

                XmlNode dataCompileNode = document.CreateElement("Compile", "http://schemas.microsoft.com/developer/msbuild/2003");
                XmlAttribute dataAttribute = document.CreateAttribute("Include");
                dataAttribute.Value = Path.Combine(table.Name, daoPrefix + Utility.FormatClassName(table.Name) + ".cs");
                dataCompileNode.Attributes.Append(dataAttribute);
                itemGroupNode.AppendChild(dataCompileNode);
            }

            XmlNode baseClassNode = document.CreateElement("Compile", "http://schemas.microsoft.com/developer/msbuild/2003");
            XmlAttribute baseClassAttribute = document.CreateAttribute("Include");
            baseClassAttribute.Value = "BaseIpl.cs";
            baseClassNode.Attributes.Append(baseClassAttribute);
            itemGroupNode.AppendChild(baseClassNode);

            document.Save(Path.Combine(path, projectName + ".csproj"));
        }

        /// <summary>
        /// Creates the AssemblyInfo.cs file for the project.
        /// </summary>
        /// <param name="path">The root path of the project.</param>
        /// <param name="assemblyTitle">The title of the assembly.</param>
        /// <param name="databaseName">The name of the database the assembly provides access to.</param>
        public static void CreateAssemblyInfo(string path, string assemblyTitle, string databaseName)
        {
            string assemblyInfo = Utility.GetResource("DataTierGenerator.Resources.AssemblyInfo.txt");
            assemblyInfo.Replace("#AssemblyTitle", assemblyTitle);
            assemblyInfo.Replace("#DatabaseName", databaseName);

            string propertiesDirectory = Path.Combine(path, "Properties");
            if (Directory.Exists(propertiesDirectory) == false)
            {
                Directory.CreateDirectory(propertiesDirectory);
            }

            File.WriteAllText(Path.Combine(propertiesDirectory, "AssemblyInfo.cs"), assemblyInfo);
        }

        /// <summary>
        /// Creates the SharpCore DLLs required by the generated code.
        /// </summary>
        /// <param name="path">The root path of the project</param>
        public static void CreateSharpCore(string path)
        {
            string sharpCoreDirectory = Path.Combine(Path.Combine(path, "Lib"), "SharpCore");
            if (Directory.Exists(sharpCoreDirectory) == false)
            {
                Directory.CreateDirectory(sharpCoreDirectory);
            }

            //Utility.WriteResourceToFile("DataTierGenerator.Resources.SharpCore.Framework.dll", Path.Combine(sharpCoreDirectory, "Framework.dll"));
            //Utility.WriteResourceToFile("DataTierGenerator.Resources.SharpCore.Dapper.dll", Path.Combine(sharpCoreDirectory, "Dapper.dll"));
        }
        /// <summary>
        /// Creates the base entity.
        /// </summary>
        /// <param name="targetNamespace">The target namespace.</param>
        /// <param name="path">The path.</param>
        public static void CreateBaseEntity(string targetNamespace, string path)
        {
            using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path, "BaseEntity.cs")))
            {
                // Create the header for the class
                streamWriter.WriteLine("using System;");
                streamWriter.WriteLine();
                streamWriter.WriteLine("namespace " + targetNamespace);
                streamWriter.WriteLine("{");
                streamWriter.WriteLine("\tpublic class BaseEntity<TKey>");
                streamWriter.WriteLine("\t{");

                // Append the public properties
                streamWriter.WriteLine("\t\t#region Properties");
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Gets or sets the identifier");
                streamWriter.WriteLine("\t\t/// " + DateTime.Now.ToString("u"));
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t[CrudField(CrudFieldType.Update | CrudFieldType.Delete)] // Just use in proceduce update/delete");
                streamWriter.WriteLine("\t\tpublic TKey Id { get; set; }");
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Gets or sets the created date.");
                streamWriter.WriteLine("\t\t/// " + DateTime.Now.ToString("u"));
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t [CrudField(UsedFor = CrudFieldType.DontUse)] // Dont use this properties in proceduce insert/update/delete");
                streamWriter.WriteLine("\t\tpublic DateTime CreatedDate { get; set; }");
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Gets or sets the modified date.");
                streamWriter.WriteLine("\t\t/// " + DateTime.Now.ToString("u"));
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t [CrudField(UsedFor = CrudFieldType.DontUse)] // Dont use this properties in proceduce insert/update/delete");
                streamWriter.WriteLine("\t\tpublic DateTime ModifiedDate { get; set; }");
                streamWriter.WriteLine();
                streamWriter.WriteLine("\t\t#endregion");

                // Close out the class and namespace
                streamWriter.WriteLine("\t}");
                streamWriter.WriteLine("}");
            }
        }

        /// <summary>
        /// Creates a C# class for all of the table's stored procedures.
        /// </summary>
        /// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
        /// <param name="targetNamespace">The namespace that the generated C# classes should contained in.</param>
        /// <param name="daoSuffix">The suffix to be appended to the data access class.</param>
        /// <param name="path">Path where the class should be created.</param>
        public static void CreateDataTransferClass(Table table, string targetNamespace, string dtoSuffix, string path)
        {
            string className1 = Utility.FormatClassName(table.Name);
            var aTable = table.Name.Split('_');
            if (aTable.Length > 1)
            {
                className1 = table.Name.Replace(aTable[0] + "_", "");
            }

            var className = className1 + dtoSuffix;
            //string className = Utility.FormatClassName(table.Name) + dtoSuffix;
            path = Path.Combine(path, className1);
            using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path, className + ".cs")))
            {
                var typeId = Utility.CreateMethodParameter(table.Columns[0]).Split(' ')[0];
                // Create the header for the class
                streamWriter.WriteLine("using System;");
                streamWriter.WriteLine("using System.ComponentModel.DataAnnotations.Schema;");
                streamWriter.WriteLine();
                streamWriter.WriteLine("namespace " + targetNamespace);
                streamWriter.WriteLine("{");
                streamWriter.WriteLine("\t[Table(\"" + table.Name + "\")]");
                streamWriter.WriteLine("\tpublic class " + className + ": BaseEntity<" + typeId + ">");
                streamWriter.WriteLine("\t{");

                // Append the public properties
                streamWriter.WriteLine("\t\t#region Properties");
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    Column column = table.Columns[i];
                    string parameter = Utility.CreateMethodParameter(column);
                    string type = parameter.Split(' ')[0];
                    string name = parameter.Split(' ')[1];
                    if (!Utility.FormatPascal(name).Equals("Id") || !Utility.FormatPascal(name).Equals("CreatedDate") || !Utility.FormatPascal(name).Equals("ModifiedDate"))
                    {
                        streamWriter.WriteLine("\t\t/// <summary>");
                        streamWriter.WriteLine("\t\t/// auto generator");
                        streamWriter.WriteLine("\t\t/// Gets or sets the " + Utility.FormatPascal(name) + " value.");
                        streamWriter.WriteLine("\t\t/// " + DateTime.Now.ToString("u"));
                        streamWriter.WriteLine("\t\t/// </summary>");
                        streamWriter.WriteLine("\t\tpublic " + type + " " + Utility.FormatPascal(name) + " { get; set; }");
                        if (i < (table.Columns.Count - 1))
                        {
                            streamWriter.WriteLine();
                        }
                    }
                }

                streamWriter.WriteLine();
                streamWriter.WriteLine("\t\t#endregion");

                // Close out the class and namespace
                streamWriter.WriteLine("\t}");
                streamWriter.WriteLine("}");
            }
        }
        public static void CreateIBaseService(string targetNamespace, string path)
        {
            var interfaceName = "IBaseService";
            using (var streamWriter = new StreamWriter(Path.Combine(path, interfaceName + ".cs")))
            {
                // Create the header for the class
                streamWriter.WriteLine("using System;");
                streamWriter.WriteLine("using System.Collections.Generic;");
                streamWriter.WriteLine();
                streamWriter.WriteLine("namespace " + targetNamespace);
                streamWriter.WriteLine("{");

                streamWriter.WriteLine("\tpublic interface " + interfaceName + "<T,TKey>");
                streamWriter.WriteLine("\t{");


                streamWriter.WriteLine("\t\t IEnumerable<T> GetAll();");
                streamWriter.WriteLine("\t\t IEnumerable<T> GetPaging(int pageIndex, int pageSize, ref int totalRow);");
                streamWriter.WriteLine("\t\t T GetById(TKey id);");
                streamWriter.WriteLine("\t\t TKey Insert(T entity);");
                streamWriter.WriteLine("\t\t bool Update(T entity);");
                streamWriter.WriteLine("\t\t  bool Delete(TKey id);");
                // Close out the class and namespace
                streamWriter.WriteLine("\t}");
                streamWriter.WriteLine("}");
            }
        }
        public static void CreateBaseClass(string targetNamespace, string path)
        {

            using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path, "BaseService.cs")))
            {
                // Create the header for the class
                streamWriter.WriteLine("using System;");
                streamWriter.WriteLine("using System.Linq;");
                streamWriter.WriteLine("using Framework;");
                streamWriter.WriteLine("using System.Collections.Generic;");
                streamWriter.WriteLine("using Framework.Data;");
                streamWriter.WriteLine("using System.Data;");
                streamWriter.WriteLine();
                streamWriter.WriteLine("namespace " + targetNamespace);
                streamWriter.WriteLine("{");

                streamWriter.WriteLine("\tpublic class BaseService<T,TKey>: BaseIpl<ADOProvider>, IBaseServices<T, TKey>");
                streamWriter.WriteLine("\t{");
                streamWriter.WriteLine("\t private readonly string _tableName;");
                streamWriter.WriteLine("\t\tpublic T unitOfWork;");
                streamWriter.WriteLine("\t\tprotected ICacheProvider cache;");
                streamWriter.WriteLine("\t\tprotected CacheHelper cacheHelper;");
                streamWriter.WriteLine("\t\tprotected string _schema;");

                streamWriter.WriteLine();

                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Initializes a new instance of the <see cref=\"BaseIpl{T}\" /> class.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\t/// <param name=\"schema\">The schema.</param>");
                streamWriter.WriteLine("\t\tpublic BaseService()");
                streamWriter.WriteLine("\t\t{");
                streamWriter.WriteLine("\t\t\t_tableName = GetTableName();");
                streamWriter.WriteLine("\t\t}");
                #region base command
                streamWriter.WriteLine("\t\tpublic IEnumerable<T> GetAll(){");
                streamWriter.WriteLine("\t\tstring procedure = GetAllCommand();");
                streamWriter.WriteLine("\t\treturn unitOfWork.Procedure<T>(procedure);");
                streamWriter.WriteLine("\t\t}");
                //Get All Paging
                streamWriter.WriteLine("\t\tpublic IEnumerable<T> GetPaging(int pageIndex, int pageSize, ref int totalRow){");
                streamWriter.WriteLine("\t\tstring procedure = GetByPagingCommand();");
                streamWriter.WriteLine("\t\tvar p = new DynamicParameters();");
                streamWriter.WriteLine("\t\tp.Add(\"@pageIndex\", pageIndex);");
                streamWriter.WriteLine("\t\tp.Add(\"@pageSize\", pageSize);");
                streamWriter.WriteLine("\t\tp.Add(\"@totalRow\", dbType: DbType.Int32, direction: ParameterDirection.Output);");
                streamWriter.WriteLine("\t\tvar data = unitOfWork.Procedure<T>(procedure, p);");
                streamWriter.WriteLine("\t\ttotalRow = p.Get<int>(\"@totalRow\");");
                streamWriter.WriteLine("\t\treturn data;");
                streamWriter.WriteLine("\t\t}");
                //Close all paging
                //Get By Id
                streamWriter.WriteLine("\t\tpublic  T GetById(TKey id){");
                streamWriter.WriteLine("\t\tstring procedure = GetByIdCommand();");
                streamWriter.WriteLine("\t\tvar p = new DynamicParameters();");
                streamWriter.WriteLine("\t\tp.Add(\"@Id\", id);");
                streamWriter.WriteLine("\t\t return unitOfWork.Procedure<T>(procedure, p).SingleOrDefault();");
                streamWriter.WriteLine("\t\t}");
                //Close byId
                //Insert
                streamWriter.WriteLine("\t\tpublic TKey Insert(T entity){");
                streamWriter.WriteLine("\t\tbool flag = false;");
                streamWriter.WriteLine("\t\tstring procedure = GetInsertCommand();");
                streamWriter.WriteLine("\t\tvar p = InsertCommand(entity);");
                streamWriter.WriteLine("\t\tflag = (bool)unitOfWork.ProcedureExecute(procedure, p);");
                streamWriter.WriteLine("\t\tif (flag){");
                streamWriter.WriteLine("\t\tvar idReturn = (TKey)Convert.ChangeType(p.parameters[\"Id\"].AttachedParam.Value, typeof(TKey));");
                streamWriter.WriteLine("\t\treturn idReturn;");
                streamWriter.WriteLine("\t\t}");
                streamWriter.WriteLine("\t\treturn (TKey)Convert.ChangeType(0, typeof(TKey));");
                streamWriter.WriteLine("\t\t}");
                //Close Insert
                //Update
                streamWriter.WriteLine("\t\tpublic bool Update(T entity){");
                streamWriter.WriteLine("\t\tbool flag = false;");
                streamWriter.WriteLine("\t\tstring procedure = GetUpdateCommand();");
                streamWriter.WriteLine("\t\tvar p = UpdateParameters(entity);");
                streamWriter.WriteLine("\t\tflag = (bool)unitOfWork.ProcedureExecute(procedure, p);");
                streamWriter.WriteLine("\t\treturn tflag;");
                streamWriter.WriteLine("\t\t}");
                //Close Update
                //Delete
                streamWriter.WriteLine("\t\tpublic  bool Delete(TKey id){");
                streamWriter.WriteLine("\t\tbool flag = false;");
                streamWriter.WriteLine("\t\tstring procedure = GetDeleteCommand();");
                streamWriter.WriteLine("\t\tvar p = new DynamicParameters();");
                streamWriter.WriteLine("\t\tp.Add(\"@Id\", id);");
                streamWriter.WriteLine("\t\tflag = (bool)unitOfWork.ProcedureExecute(procedure, p);");
                streamWriter.WriteLine("\t\treturn tflag;");
                streamWriter.WriteLine("\t\t}");
                //Close Delete
                #endregion
                #region Sql Command
                streamWriter.WriteLine("\t\tprivate string GetTableName(){");
                streamWriter.WriteLine("\t\tvar attr = typeof(T).CustomAttributes.FirstOrDefault(c => c.AttributeType.Name == \"TableAttribute\");");
                streamWriter.WriteLine("\t\tif (attr == null)");
                streamWriter.WriteLine("\t\t\tthrow new ArgumentNullException(\"TableAttribute not found\");");
                streamWriter.WriteLine("\t\treturn (string)attr.ConstructorArguments[0].Value;");
                streamWriter.WriteLine("\t\t}");
                streamWriter.WriteLine("\t\tpublic string TableName{ get { return _tableName; }}");
                streamWriter.WriteLine("\t\tprivate string GetInsertCommand(){return $\"sp_{TableName}_Insert\";}");
                streamWriter.WriteLine("\t\tprivate string GetUpdateCommand(){return $\"sp_{TableName}_Update\";}");
                streamWriter.WriteLine("\t\tprivate string GetDeleteCommand(){return $\"sp_{TableName}_Delete\";}");
                streamWriter.WriteLine("\t\tprivate string GetAllCommand(){return $\"sp_{TableName}_GetAll\";}");
                streamWriter.WriteLine("\t\tprivate string GetByPagingCommand(){return $\"sp_{TableName}_GetPaging\";}");
                streamWriter.WriteLine("\t\tprivate string GetByIdCommand(){return $\"sp_{TableName}_GetById\";}");
                #endregion
                #region paramester command
                streamWriter.WriteLine("\t\tprivate DynamicParameters InsertCommand(T entity)");
                streamWriter.WriteLine("\t\t{");
                streamWriter.WriteLine("\t\tvar allParams = DataHelper.GetSQLParametersFromPublicProperties(entity, Framework.Data.Attributes.CrudFieldType.Create);");
                streamWriter.WriteLine("\t\tallParams.Add(\"@Id\", dbType: DbType.Int64, direction: ParameterDirection.Output);");
                streamWriter.WriteLine("\t\treturn allParams;");
                streamWriter.WriteLine("\t\t}");
                streamWriter.WriteLine("\t\tprivate DynamicParameters UpdateParameters(T entity)");
                streamWriter.WriteLine("\t\t{");
                streamWriter.WriteLine("\t\t var allParams = DataHelper.GetSQLParametersFromPublicProperties(entity, Framework.Data.Attributes.CrudFieldType.Update);");
                streamWriter.WriteLine("\t\treturn allParams;");
                streamWriter.WriteLine("\t\t}");
                #endregion
                // Close out the class and namespace
                streamWriter.WriteLine("\t}");
                streamWriter.WriteLine("}");
            }
        }

        public static void CreateInterfaceClass(Table table, string targetNamespace, string dtoSuffix, string path)
        {
            string entityName = Utility.FormatClassName(table.Name);
            var aTable = table.Name.Split('_');
            if (aTable.Length > 1)
            {
                entityName = table.Name.Replace(aTable[0] + "_", "");
            }

            entityName += dtoSuffix;

            //string entityName = Utility.FormatClassName(table.Name) + dtoSuffix;
            //string interfaceName = "I" + Utility.FormatClassName(table.Name);
            string interfaceName = "I" + entityName.Replace("Entity", "");
            path = Path.Combine(path, entityName.Replace("Entity", ""));
            using (var streamWriter = new StreamWriter(Path.Combine(path, interfaceName + ".cs")))
            {
                var typeId = Utility.CreateMethodParameter(table.Columns[0]).Split(' ')[0];
                // Create the header for the class
                streamWriter.WriteLine("using System;");
                streamWriter.WriteLine("using System.Collections.Generic;");
                streamWriter.WriteLine();
                streamWriter.WriteLine("namespace " + targetNamespace);
                streamWriter.WriteLine("{");
                streamWriter.WriteLine("\tpublic interface " + interfaceName + " : IBaseServices<" + entityName + ", " + typeId + ">{ }");
                streamWriter.WriteLine("}");
            }
        }

        /// <summary>
        /// Creates a C# data access class for all of the table's stored procedures.
        /// </summary>
        /// <param name="databaseName">The name of the database.</param>
        /// <param name="table">Instance of the Table class that represents the table this class will be created for.</param>
        /// <param name="targetNamespace">The namespace that the generated C# classes should contained in.</param>
        /// <param name="storedProcedurePrefix">Prefix to be appended to the name of the stored procedure.</param>
        /// <param name="daoPrefix">The suffix to be appended to the data access class.</param>
        /// <param name="dtoSuffix">The suffix to append to the name of each data transfer class.</param>
        /// <param name="path">Path where the class should be created.</param>
        public static void CreateDataAccessClass(string databaseName, Table table, string targetNamespace, string storedProcedurePrefix, string daoPrefix, string dtoSuffix, string path)
        {
            //string className = daoPrefix + Utility.FormatClassName(table.Name);
            string className = Utility.FormatClassName(table.Name);
            var aTable = table.Name.Split('_');
            if (aTable.Length > 1)
            {
                className = table.Name.Replace(aTable[0] + "_", "");
            }

            var iplClassName = daoPrefix + className;
            path = Path.Combine(path, className);
            //string entityName = Utility.FormatClassName(table.Name) + dtoSuffix;
            //string entityName = className.Replace("Entity", "") + dtoSuffix;
            string entityName = className.Replace("Entity", "");
            var typeId = Utility.CreateMethodParameter(table.Columns[0]).Split(' ')[0];
            using (StreamWriter streamWriter = new StreamWriter(Path.Combine(path, iplClassName + ".cs")))
            {
                //// Create the header for the class
                //streamWriter.WriteLine("using System;");
                //streamWriter.WriteLine("using System.Collections.Generic;");
                //streamWriter.WriteLine("using System.Data;");
                //streamWriter.WriteLine("using System.Data.SqlClient;");
                //streamWriter.WriteLine("using System.Linq;");
                //streamWriter.WriteLine("using Framework;");
                //streamWriter.WriteLine("using Framework.Data;");
                //streamWriter.WriteLine("using Framework.Helper.Logging;");
                //streamWriter.WriteLine();



                streamWriter.WriteLine("namespace " + targetNamespace);
                streamWriter.WriteLine("{");

                streamWriter.WriteLine("\tpublic class " + iplClassName + " : BaseService<" + className + "Entity, " + typeId + ">, I" + entityName);
                streamWriter.WriteLine("\t{");
                // Append the fields
                streamWriter.WriteLine();
                // Append the constructors
                streamWriter.WriteLine("\t\tpublic " + iplClassName + "(){ }");

                //// Append the access methods
                //streamWriter.WriteLine("\t\t#region Methods");
                //streamWriter.WriteLine();
                //CreateInsertMethod(table, storedProcedurePrefix, dtoSuffix, streamWriter);
                //CreateUpdateMethod(table, storedProcedurePrefix, dtoSuffix, streamWriter);
                //CreateDeleteMethod(table, storedProcedurePrefix, streamWriter);
                //CreateSelectMethod(table, storedProcedurePrefix, dtoSuffix, streamWriter);
                //CreateSelectAllMethod(table, storedProcedurePrefix, dtoSuffix, streamWriter);
                //CreateSelectAllPagingMethod(table, storedProcedurePrefix, dtoSuffix, streamWriter);
                //CreateParamMethod(table, storedProcedurePrefix, dtoSuffix, streamWriter);
                //streamWriter.WriteLine();
                //streamWriter.WriteLine("\t\t#endregion");

                // Close out the class and namespace
                streamWriter.WriteLine("\t}");
                streamWriter.WriteLine("}");
            }
        }

        /// <summary>
        /// Creates a string that represents the insert functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="storedProcedurePrefix">The prefix that is used on the stored procedure that this method will call.</param>
        /// <param name="dtoSuffix">The suffix to append to the name of each data transfer class.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        private static void CreateInsertMethod(Table table, string storedProcedurePrefix, string dtoSuffix, StreamWriter streamWriter)
        {
            string className = Utility.FormatClassName(table.Name) + dtoSuffix;
            string variableName = Utility.FormatVariableName(table.Name);
            var col = Utility.GetOutputColumn(table);
            // Append the method header
            streamWriter.WriteLine("\t\t/// <summary>");
            streamWriter.WriteLine("\t\t/// Saves a record to the " + table.Name + " table.");
            streamWriter.WriteLine("\t\t/// </summary>");
            // Append the parameter declarations
            streamWriter.Write("\t\tpublic " + (col != null ? Utility.GetCsType(col) : "Int32") + " Insert(" + className + " " + variableName + ")");
            streamWriter.WriteLine("\t\t{");
            // Append validation for the parameter
            if (col != null)
            {
                streamWriter.WriteLine("\t\t\t" + Utility.GetCsType(col) + " res = 0;");
            }
            streamWriter.WriteLine("\t\t\tbool flag = false;");

            if (col != null)
            {
                streamWriter.WriteLine("\t\t\ttry");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tvar p = Param(" + variableName + ");");
                streamWriter.WriteLine("\t\t\t\tflag = (bool)unitOfWork.ProcedureExecute(\"" + storedProcedurePrefix + Utility.FormatClassName(table.Name) + "_Insert\", p);");
                streamWriter.WriteLine("\t\t\t\tif (flag)");
                streamWriter.WriteLine("\t\t\t\t{");
                streamWriter.WriteLine("\t\t\t\t\tres = p.Get<" + Utility.GetCsType(col) + ">(\"@" + Utility.FormatClassName(col.Name) + "\");");
                streamWriter.WriteLine("\t\t\t\t}");
                streamWriter.WriteLine("\t\t\t\telse");
                streamWriter.WriteLine("\t\t\t\t{");
                streamWriter.WriteLine("\t\t\t\t\tres = 0;");
                streamWriter.WriteLine("\t\t\t\t}");
                streamWriter.WriteLine("\t\t\t}");
                streamWriter.WriteLine("\t\t\tcatch (Exception ex)");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tLogging.PutError(ex.Message , ex);");
                streamWriter.WriteLine("\t\t\t\tthrow;");
                streamWriter.WriteLine("\t\t\t}");
                streamWriter.WriteLine("\t\t\treturn res;");
            }
            else
            {
                streamWriter.WriteLine("\t\t\ttry");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tvar p = Param(" + variableName + ");");
                streamWriter.WriteLine("\t\t\t\tflag = (bool)unitOfWork.ProcedureExecute(\"" + storedProcedurePrefix + Utility.FormatClassName(table.Name) + "_Insert\", p);");
                streamWriter.WriteLine("\t\t\t\tif (flag)");
                streamWriter.WriteLine("\t\t\t\t\treturn 1;");
                streamWriter.WriteLine("\t\t\t\treturn 0;");
                streamWriter.WriteLine("\t\t\t}");
                streamWriter.WriteLine("\t\t\tcatch (Exception ex)");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tLogging.PutError(ex.Message , ex);");
                streamWriter.WriteLine("\t\t\t\tthrow;");
                streamWriter.WriteLine("\t\t\t}");
                streamWriter.WriteLine("\t\t\treturn 0;");
            }


            // Append the method footer
            streamWriter.WriteLine("\t\t}");
            streamWriter.WriteLine();
        }
        private static void CreateParamMethod(Table table, string storedProcedurePrefix, string dtoSuffix, StreamWriter streamWriter)
        {

            string className = Utility.FormatClassName(table.Name) + dtoSuffix;
            string variableName = Utility.FormatVariableName(Utility.FormatClassName(table.Name));
            // Append the method header
            streamWriter.WriteLine("\t\t/// <summary>");
            streamWriter.WriteLine("\t\t/// Saves a record to the " + table.Name + " table.");
            streamWriter.WriteLine("\t\t/// </summary>");
            // Append the parameter declarations
            streamWriter.Write("\t\tprivate DynamicParameters Param(" + className + " " + variableName + ", string action = \"add\"");
            streamWriter.WriteLine(")");
            streamWriter.WriteLine("\t\t{");
            streamWriter.WriteLine("\t\t\tvar p = new DynamicParameters();");
            // Append validation for the parameter
            foreach (Column column in table.Columns)
            {
                if (column.IsIdentity == false && column.IsRowGuidCol == false)
                {
                    streamWriter.WriteLine("\t\t\tp.Add(\"@" + Utility.FormatPascal(column.Name) + "\", " + variableName + "." + Utility.FormatPascal(column.Name) + ");");
                }
                else
                {
                    streamWriter.WriteLine("\t\t\tif (action == \"edit\")");
                    streamWriter.WriteLine("\t\t\t{");
                    streamWriter.WriteLine("\t\t\t\tp.Add(\"@" + Utility.FormatPascal(column.Name) + "\", " + variableName + "." + Utility.FormatPascal(column.Name) + ");");
                    streamWriter.WriteLine("\t\t\t}");
                    streamWriter.WriteLine("\t\t\telse");
                    streamWriter.WriteLine("\t\t\t{");
                    streamWriter.WriteLine("\t\t\t\tp.Add(\"@" + Utility.FormatPascal(column.Name) + "\", dbType: DbType." + Utility.GetReturnDbType(column.Type) + ", direction: ParameterDirection.Output);");
                    streamWriter.WriteLine("\t\t\t}");
                }
            }
            streamWriter.WriteLine("\t\t\treturn p;");
            // Append the method footer
            streamWriter.WriteLine("\t\t}");
            streamWriter.WriteLine();
        }

        /// <summary>
        /// Creates a string that represents the update functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="storedProcedurePrefix">The prefix that is used on the stored procedure that this method will call.</param>
        /// <param name="dtoSuffix">The suffix to append to the name of each data transfer class.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        private static void CreateUpdateMethod(Table table, string storedProcedurePrefix, string dtoSuffix, StreamWriter streamWriter)
        {
            if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count)
            {
                string className = Utility.FormatClassName(table.Name) + dtoSuffix;
                string variableName = Utility.FormatVariableName(table.Name);

                // Append the method header
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Updates a record in the " + table.Name + " table.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\tpublic bool Update(" + className + " " + variableName + ")");
                streamWriter.WriteLine("\t\t{");

                // Append the parameter declarations
                streamWriter.WriteLine("\t\t\tbool res = false;");
                streamWriter.WriteLine("\t\t\ttry");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tvar p = Param(" + variableName + ", \"edit\");");
                streamWriter.WriteLine("\t\t\t\tres = (bool)unitOfWork.ProcedureExecute(\"" + storedProcedurePrefix + Utility.FormatClassName(table.Name) + "_Update\", p);");
                streamWriter.WriteLine("\t\t\t\treturn res;");
                streamWriter.WriteLine("\t\t\t}");
                streamWriter.WriteLine("\t\t\tcatch (Exception ex)");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tLogging.PutError(ex.Message , ex);");
                streamWriter.WriteLine("\t\t\t\tthrow;");
                streamWriter.WriteLine("\t\t\t}");

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
                streamWriter.WriteLine();
            }
        }

        /// <summary>
        /// Creates a string that represents the delete functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="storedProcedurePrefix">The prefix that is used on the stored procedure that this method will call.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        private static void CreateDeleteMethod(Table table, string storedProcedurePrefix, StreamWriter streamWriter)
        {
            if (table.PrimaryKeys.Count > 0)
            {
                // Append the method header
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Deletes a record from the " + table.Name + " table by its primary key.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.Write("\t\tpublic bool Delete(");
                for (int i = 0; i < table.PrimaryKeys.Count; i++)
                {
                    Column column = table.PrimaryKeys[i];
                    streamWriter.Write(Utility.CreateMethodParameter(column));
                    if (i < (table.PrimaryKeys.Count - 1))
                    {
                        streamWriter.Write(", ");
                    }
                }
                streamWriter.WriteLine(")");
                streamWriter.WriteLine("\t\t{");

                // Append the parameter declarations
                streamWriter.WriteLine("\t\t\ttry");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tbool res = false;");
                streamWriter.WriteLine("\t\t\t\tvar p = new DynamicParameters();");
                for (int i = 0; i < table.PrimaryKeys.Count; i++)
                {
                    Column column = table.PrimaryKeys[i];
                    streamWriter.WriteLine("\t\t\t\tp.Add(\"@" + Utility.FormatClassName(column.Name) + "\", " + Utility.FormatCamel(column.Name) + ");");
                }

                streamWriter.WriteLine("\t\t\t\tres = (bool)unitOfWork.ProcedureExecute(\"" + storedProcedurePrefix + Utility.FormatClassName(table.Name) + "_Delete\", p);");
                streamWriter.WriteLine("\t\t\t\treturn res;");
                streamWriter.WriteLine("\t\t\t}");
                streamWriter.WriteLine("\t\t\tcatch (Exception ex)");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tLogging.PutError(ex.Message , ex);");
                streamWriter.WriteLine("\t\t\t\tthrow;");
                streamWriter.WriteLine("\t\t\t}");

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
                streamWriter.WriteLine();
            }
        }


        /// <summary>
        /// Creates a string that represents the select by primary key functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="storedProcedurePrefix">The prefix that is used on the stored procedure that this method will call.</param>
        /// <param name="dtoSuffix">The suffix to append to the name of each data transfer class.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        private static void CreateSelectMethod(Table table, string storedProcedurePrefix, string dtoSuffix, StreamWriter streamWriter)
        {
            if (table.PrimaryKeys.Count > 0 && table.Columns.Count != table.ForeignKeys.Count)
            {
                string className = Utility.FormatClassName(table.Name) + dtoSuffix;

                // Append the method header
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Selects a single record from the " + table.Name + " table.");
                streamWriter.WriteLine("\t\t/// </summary>");

                streamWriter.Write("\t\tpublic " + className + " ViewDetail(");
                for (int i = 0; i < table.PrimaryKeys.Count; i++)
                {
                    Column column = table.PrimaryKeys[i];
                    streamWriter.Write(Utility.CreateMethodParameter(column));
                    if (i < (table.PrimaryKeys.Count - 1))
                    {
                        streamWriter.Write(", ");
                    }
                }
                streamWriter.WriteLine(")");
                streamWriter.WriteLine("\t\t{");

                streamWriter.WriteLine("\t\t\ttry");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tvar p = new DynamicParameters();");
                for (int i = 0; i < table.PrimaryKeys.Count; i++)
                {
                    Column column = table.PrimaryKeys[i];
                    streamWriter.WriteLine("\t\t\t\tp.Add(\"@" + Utility.FormatClassName(column.Name) + "\", " + Utility.FormatCamel(column.Name) + ");");
                }
                streamWriter.WriteLine("\t\t\t\tvar data = unitOfWork.Procedure<" + className + ">(\"" + storedProcedurePrefix + Utility.FormatClassName(table.Name) + "_ViewDetail\", p).SingleOrDefault();");
                streamWriter.WriteLine("\t\t\t\treturn data;");
                streamWriter.WriteLine("\t\t\t}");
                streamWriter.WriteLine("\t\t\tcatch (Exception ex)");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tLogging.PutError(ex.Message , ex);");
                streamWriter.WriteLine("\t\t\t\treturn null;");
                streamWriter.WriteLine("\t\t\t}");

                streamWriter.WriteLine();

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
                streamWriter.WriteLine();
            }
        }


        /// <summary>
        /// Creates a string that represents the select functionality of the data access class.
        /// </summary>
        /// <param name="table">The Table instance that this method will be created for.</param>
        /// <param name="storedProcedurePrefix">The prefix that is used on the stored procedure that this method will call.</param>
        /// <param name="dtoSuffix">The suffix to append to the name of each data transfer class.</param>
        /// <param name="streamWriter">The StreamWriter instance that will be used to create the method.</param>
        private static void CreateSelectAllMethod(Table table, string storedProcedurePrefix, string dtoSuffix, StreamWriter streamWriter)
        {
            if (table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count)
            {
                string className = Utility.FormatClassName(table.Name) + dtoSuffix;
                string dtoVariableName = Utility.FormatCamel(className);

                // Append the method header
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\tpublic List<" + className + "> ListAll()");
                streamWriter.WriteLine("\t\t{");

                // Append the stored procedure execution
                streamWriter.WriteLine("\t\t\ttry");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tvar data = unitOfWork.Procedure<" + className + ">(\"" + storedProcedurePrefix + Utility.FormatClassName(table.Name) + "_ListAll\");");
                streamWriter.WriteLine("\t\t\t\treturn data.ToList();");
                streamWriter.WriteLine("\t\t\t}");
                streamWriter.WriteLine("\t\t\tcatch (Exception ex)");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tLogging.PutError(ex.Message , ex);");
                streamWriter.WriteLine("\t\t\t\tthrow;");
                streamWriter.WriteLine("\t\t\t}");

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
                streamWriter.WriteLine();
            }
        }
        private static void CreateSelectAllPagingMethod(Table table, string storedProcedurePrefix, string dtoSuffix, StreamWriter streamWriter)
        {
            if (table.Columns.Count != table.PrimaryKeys.Count && table.Columns.Count != table.ForeignKeys.Count)
            {
                string className = Utility.FormatClassName(table.Name) + dtoSuffix;
                string dtoVariableName = Utility.FormatCamel(className);

                // Append the method header
                streamWriter.WriteLine("\t\t/// <summary>");
                streamWriter.WriteLine("\t\t/// Selects all records from the " + table.Name + " table.");
                streamWriter.WriteLine("\t\t/// </summary>");
                streamWriter.WriteLine("\t\tpublic List<" + className + "> ListAllPaging(int pageIndex, int pageSize, ref int totalRow)");
                streamWriter.WriteLine("\t\t{");

                // Append the stored procedure execution
                streamWriter.WriteLine("\t\t\ttry");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tvar p = new DynamicParameters();");
                streamWriter.WriteLine("\t\t\t\tp.Add(\"@pageIndex\", pageIndex);");
                streamWriter.WriteLine("\t\t\t\tp.Add(\"@pageSize\", pageSize);");
                streamWriter.WriteLine("\t\t\t\tp.Add(\"@totalRow\", dbType: DbType.Int32, direction: ParameterDirection.Output);");
                streamWriter.WriteLine("\t\t\t\tvar data = unitOfWork.Procedure<" + className + ">(\"" + storedProcedurePrefix + Utility.FormatClassName(table.Name) + "_ListAllPaging\", p);");
                streamWriter.WriteLine("\t\t\t\ttotalRow = p.Get<int>(\"@totalRow\");");
                streamWriter.WriteLine("\t\t\t\treturn data.ToList();");
                streamWriter.WriteLine("\t\t\t}");
                streamWriter.WriteLine("\t\t\tcatch (Exception ex)");
                streamWriter.WriteLine("\t\t\t{");
                streamWriter.WriteLine("\t\t\t\tLogging.PutError(ex.Message , ex);");
                streamWriter.WriteLine("\t\t\t\tthrow;");
                streamWriter.WriteLine("\t\t\t}");

                // Append the method footer
                streamWriter.WriteLine("\t\t}");
                streamWriter.WriteLine();
            }
        }

    }
}
